package com.itp.model;

public class rawMaterial {

	private String rawMaterialID;
	
	private String rawMaterialName;
	
	private String rawMaterialDes;
	
	private String storeID;
	
	private double unitPrice;
	
	private String status;

	public String getRawMaterialID() {
		return rawMaterialID;
	}

	public void setRawMaterialID(String rawMaterialID) {
		this.rawMaterialID = rawMaterialID;
	}

	public String getRawMaterialName() {
		return rawMaterialName;
	}

	public void setRawMaterialName(String rawMaterialName) {
		this.rawMaterialName = rawMaterialName;
	}

	public String getRawMaterialDes() {
		return rawMaterialDes;
	}

	public void setRawMaterialDes(String rawMaterialDes) {
		this.rawMaterialDes = rawMaterialDes;
	}

	public String getStoreID() {
		return storeID;
	}

	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
}
