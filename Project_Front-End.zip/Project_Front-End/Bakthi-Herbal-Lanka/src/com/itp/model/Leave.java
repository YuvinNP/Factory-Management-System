
/**
 * 
 */
package com.itp.model;

/**
 * @author Yuvin Nimnaka
 *
 */
public class Leave {

}
